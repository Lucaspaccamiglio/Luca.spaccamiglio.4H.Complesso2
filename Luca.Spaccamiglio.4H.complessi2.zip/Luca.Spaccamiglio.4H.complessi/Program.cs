﻿using System;

namespace Luca.Spaccamiglio._4H.complessi
{
    class Program
    {
        static void Main(string[] args)
        {
            string stroperatore;

            Console.WriteLine("Inserisci l'operatore (1 per somma, 2 per differenza, 3 prodotto, 4 diviso)");
            stroperatore = Console.ReadLine();

            int operatore = Convert.ToInt32(stroperatore);

            Complesso z1 = new Complesso(5, 3);
            Complesso z2 = new Complesso(2, 1);
            Complesso ztot= new Complesso(0,0);
            
            if (operatore == 1)
            {
                
                Console.WriteLine("la somma è: {0} {1}", ztot.reale, ztot.immaginario);
                
            }

            if (operatore == 2)
            {
                Console.WriteLine("la differenza è: {0} {1}", ztot.reale, ztot.immaginario);
            }

            if (operatore == 3)
            {
                Console.WriteLine("la moltiplicazione è: {0} {1}", ztot.reale, ztot.immaginario);
            }
            if (operatore == 4)
            {
                Console.WriteLine("la divisione è: {0} {1}", ztot.reale, ztot.immaginario);
            }
        } 
        class Complesso
        {
            public int reale;
            public int immaginario;

            public Complesso(int a, int b)
            {
                reale = a;
                immaginario = b;
            }

            public void somma( Complesso z1, Complesso z2, Complesso ztot)
            {
                ztot.reale = z1.reale + z2.reale;
                ztot.immaginario = z1.immaginario + z2.immaginario;
                
            }
            public void sottrazione(Complesso z1, Complesso z2, Complesso ztot)
            { 
                ztot.reale = z1.reale - z2.reale;
                ztot.immaginario = z1.immaginario - z2.immaginario;
            }
            public void moltiplicazione(Complesso z1, Complesso z2, Complesso ztot)
            {
                ztot.reale = z1.reale * z2.reale;
                ztot.immaginario = z1.immaginario * z2.immaginario;
            }
            public void divisione(Complesso z1, Complesso z2, Complesso ztot)
            {
                ztot.reale = z1.reale / z2.reale;
                ztot.immaginario = z1.immaginario / z2.immaginario;
            }

            
          
        }
    }

} 